#include "Persona.h"
#include "Streaming.h"
class Admin : private Persona
{
private:
public:
    Admin(string nombre);
    ~Admin();
    void agregarPelicula(Streaming *, string, float, string, float, string);
    void agregarSerie(Streaming *, string, string);
    void agregarCapitulos(Streaming *, string, string, int, float, float);
    void borrarSerie(Streaming *, string);
    void borrarPelicula(Streaming *, string);
    void borrarTodasLasPeliculas(Streaming *);
};
