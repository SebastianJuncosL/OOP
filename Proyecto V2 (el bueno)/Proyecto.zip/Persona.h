#include <string>
using namespace std;

#pragma once
class Persona
{
private:
    string *nombre;

public:
    Persona(string nombre);
    ~Persona();
};

